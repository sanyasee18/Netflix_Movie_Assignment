package com.example.crud.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.crud.dto.EmployeeDTO;
import com.example.crud.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
	
	private Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	@Autowired
	private EmployeeService employeeService;

	@GetMapping
	public List<EmployeeDTO> listAllEmployees(){
		
		logger.info("entered listAllEmployees");
		
		return employeeService.getAllEmployees();
	}
	
	@PostMapping("/create")
	public ResponseEntity<EmployeeDTO> createEmployee(@RequestBody EmployeeDTO employeeDto) {
		
		logger.info("entered createEmployee");
		
		return new ResponseEntity<>(employeeService.createNewEmployee(employeeDto), HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}/update")
	public ResponseEntity<EmployeeDTO> updateEmployee(@RequestBody EmployeeDTO employeeDto,
			@PathVariable("id") int id) {
		
		logger.info("entered updateEmployee");
		
		return new ResponseEntity<>(employeeService.updateEmployee(employeeDto, id), HttpStatus.ACCEPTED);
		
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity<String> deleteEmployee(@RequestParam("id") int id) {
		
		logger.info("entered deleteEmployee");

		employeeService.deleteEmployee(id);

		return new ResponseEntity<>("Employee Deleted Successfully", HttpStatus.OK);
	}
}
