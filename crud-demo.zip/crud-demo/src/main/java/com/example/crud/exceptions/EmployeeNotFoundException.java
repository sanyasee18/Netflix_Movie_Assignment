package com.example.crud.exceptions;

public class EmployeeNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public EmployeeNotFoundException() {
		super("Employee is not present in DB");
	}
	
	public EmployeeNotFoundException(String message) {
		super(message);
	}

}
