package com.example.crud.service;

import java.util.List;

import com.example.crud.dto.EmployeeDTO;

public interface EmployeeService {

	public List<EmployeeDTO> getAllEmployees();
	
	public EmployeeDTO createNewEmployee(EmployeeDTO employeeDto);

	public EmployeeDTO updateEmployee(EmployeeDTO employeeDto, int id);

	public void deleteEmployee(int id);
}
