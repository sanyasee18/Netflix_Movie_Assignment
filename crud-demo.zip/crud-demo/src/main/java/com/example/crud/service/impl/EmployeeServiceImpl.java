package com.example.crud.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.crud.dto.EmployeeDTO;
import com.example.crud.entities.Employee;
import com.example.crud.exceptions.EmployeeNotFoundException;
import com.example.crud.repositories.EmployeeRepository;
import com.example.crud.service.EmployeeService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	// method to fetch all employees
	@Override
	public List<EmployeeDTO> getAllEmployees() {

		log.info("enetered EmployeeServiceImpl.getAllEmployees");

		List<EmployeeDTO> listEmployees = new ArrayList<>();

		List<Employee> allEmployees = employeeRepository.findAll();

		// transforming Employee entity to EmployeeDto
		allEmployees.forEach(employee -> {
			EmployeeDTO emp = new EmployeeDTO();

			emp.setId(employee.getId());
			emp.setName(employee.getName());
			emp.setSalary(employee.getSalary());

			listEmployees.add(emp);
		});

		log.info("returning EmployeeServiceImpl.getAllEmployees");
		return listEmployees;
	}

	// method to create new employee
	@Override
	public EmployeeDTO createNewEmployee(EmployeeDTO employeeDto) {

		Employee employee = new Employee();

		employee.setName(employeeDto.getName());
		employee.setSalary(employeeDto.getSalary());

		// saving employee data in database
		Employee savedEmployee = employeeRepository.save(employee);

		employeeDto.setId(savedEmployee.getId());

		return employeeDto;
	}

	// method to update employee
	@Override
	public EmployeeDTO updateEmployee(EmployeeDTO employeeDto, int id) {
		// checking if employee exists
		Optional<Employee> empOptional = employeeRepository.findById(id);

		if (empOptional.isPresent()) {
			Employee employee = empOptional.get();
			employee.setName(employeeDto.getName());
			employee.setSalary(employeeDto.getSalary());

			// update employee data in DB
			Employee savedEmployee = employeeRepository.save(employee);

			employeeDto.setId(savedEmployee.getId());
			employeeDto.setName(savedEmployee.getName());
			employeeDto.setSalary(savedEmployee.getSalary());

			return employeeDto;
		}

		// throw new RuntimeException("Employee not present in DB");
		throw new EmployeeNotFoundException();
	}

	// deleting an employee from the DB
	@Override
	public void deleteEmployee(int id) {
		employeeRepository.deleteById(id);
	}

}
